---
name: analise-intimacoes-controladoria
description: Analisar e revisar intimações DJEN/VIOS, identificar duplicidades e erros, definir tarefas oficiais, responsáveis, prazos jurídicos e datas operacionais da Controladoria. Usar para planilhas de intimações, ciência, despacho, decisão, sentença, acórdão, audiência, perícia, laudo, emenda, recursos, contrarrazões, sustentação oral, RPV/precatório, guias, depósitos e providências da Controladoria Jurídica.
---

# Análise de Intimações da Controladoria

Analisar todas as CIs, sem pular nenhuma. Distinguir providência jurídica, departamento interno, auxiliar, vencimento jurídico e data da tarefa. Não inventar dados nem presumir conferência nos autos.

## Fontes e referências obrigatórias

1. Ler integralmente o documento atual enviado pelo usuário. Se for relatório de análises, distinguir o que consta do relatório do que foi conferido no expediente original ou nos autos.
2. Ler [roteamento-interno.md](references/roteamento-interno.md) para departamento, responsável, duplicidades, Breno e prioridades.
3. Ler [pop-fluxo-intimacoes.md](references/pop-fluxo-intimacoes.md) para a providência e tarefas complementares.
4. Usar exclusivamente os nomes de [tarefas-vios.md](references/tarefas-vios.md); sugestões automáticas do VIOS são indícios, não decisões.
5. Ler [regras-prazos-recursos.md](references/regras-prazos-recursos.md) para termo inicial, cabimento, contagem, calendário e D-2.
6. Conferir [validacao-lancamento.md](references/validacao-lancamento.md) antes de concluir ou autorizar lançamento.
7. Consultar arquivos internos disponíveis; usar memória apenas como apoio, nunca como substituta do documento atual.

Privilegiar o documento atual para os fatos do caso. Não tratar uma análise automática anterior como fonte que prevalece sobre lei, ato oficial ou intimação original. Buscar fontes oficiais atuais para validar legislação, cabimento e suspensões quando necessário.

## Fluxo de trabalho

1. Identificar CI, processo, cliente, partes, posição processual, destinatário, órgão, fase, departamento e auxiliar. O cliente costuma estar na quarta ou quinta coluna: conferir pelo conteúdo.
2. Reconhecer que AVANTTI SOLUCOES PRESTADORA DE SERVICOS LTDA (MATRIZ), inclusive com a indicação PRESTADORA, e FAMOL COMERCIO DE MOVEIS LTDA (MATRIZ) são a mesma empresa conforme orientação institucional. Não estender essa equivalência a outras empresas sem prova. Se o cliente indicado não constar da publicação, registrar a divergência.
3. Classificar o ato e identificar a providência concreta. Separar ordem para o cliente de ordem para a parte contrária. Não atribuir ao cliente prazo da parte contrária.
4. Comparar CIs do mesmo processo pelo teor, ID da decisão, dispositivo, objeto, publicação e destinatário. Verificar duplicidade mesmo se o programa disser “ato diferente”. Não deduplicar apenas por assunto, nome ou redação padronizada.
5. Definir tarefa oficial principal e cada complementar obrigatória, com finalidade, responsável, data e resumo próprios.
6. Identificar todo prazo: manifestação, emenda, pagamento, depósito, preparo, laudo, quesitos, provas, contrarrazões, embargos e recurso. Não omitir prazo porque não cabe recurso.
7. Identificar o meio e o prazo legal de referência sem decidir pelo advogado nem suprimir controles preventivos; conferir publicação efetiva, duração e regras especiais; aplicar a contagem simplificada abaixo. Distinguir a contagem simplificada solicitada de vencimento jurídico oficialmente validado.
8. Aplicar a data operacional correta, inclusive exceções a D-2. Não relançar para data já passada: manter a data original de referência e indicar urgência/atraso à Controladoria.
9. Elaborar resumo curto que permita lançar a tarefa sem reconstruir os dados.
10. Resolver inconsistências de redação antes de finalizar. Quando depender de informação externa ausente, entregar a análise e a pendência exata, com status de não lançar para a CI/tarefa afetada. Prosseguir com as demais.

## Escolha entre análise, minuta e ciência

- Indicar sempre análise da área para sentença, acórdão ou decisão que exija avaliação jurídica, inclusive favorável. Reservar ao advogado a escolha da providência seguinte; não abrir minuta recursal antes dessa análise.
- Para sentença que encerre o processo/fase ou homologue acordo envolvendo o cliente, indicar sempre análise, mesmo favorável, cumprida, com renúncia recursal ou arquivamento. Não substituir por ciência.
- Conferir sentença e acordo/aditivos quanto a partes, valores, parcelas, vencimentos, multas, quitação, obrigações, custas, honorários e alcance da extinção. Se faltar instrumento, registrar `PENDENTE – CONFERIR A SENTENÇA COM O ACORDO E DOCUMENTOS DOS AUTOS`. Não afirmar que a homologação está correta apenas pelo relato da sentença.
- Incluir na finalidade e no resumo da análise a conferência jurídica e o prosseguimento do contato com o cliente para informar o resultado, explicar o encerramento e esclarecer providências. A tarefa de análise já gera o contato com o cliente no fluxo do VIOS. Não indicar nem criar tarefa separada de contato para duplicar essa providência.
- Indicar minuta diretamente quando a ordem já definir a manifestação objetiva a apresentar. Não abrir recurso automaticamente quando depender de análise do advogado. Contrarrazões expressamente determinadas admitem minuta direta.
- Indicar ciência para distribuição simples, mero aviso ou ato sem prazo/providência/conferência jurídica para o cliente. Na Execução, mero aviso de movimentação sem avaliação jurídica nem efeito sobre o cliente pode gerar ciência; sentença/acórdão/decisão para avaliação jurídica exige análise.
- Não usar ciência para compensar falta do teor, falta de identificação de quem recorreu ou dúvida de área/cliente.

## Datas das tarefas — aplicar a exceção antes da regra geral

### Contagem simplificada — excluir somente sábados e domingos

Por orientação expressa do usuário, aplicar a todas as contagens apresentadas nesta skill, inclusive vencimentos de referência de embargos, recursos, manifestações, obrigações e controles D-2, um calendário de segunda a sexta-feira. Contar feriados nacionais, estaduais, municipais, pontos facultativos, recesso e suspensões como dias úteis para este cálculo. Excluir somente sábados e domingos. Esta regra substitui a exigência anterior de consultar e aplicar calendários de feriados dos tribunais.

Não pesquisar feriados nem bloquear uma tarefa apenas por faltar calendário oficial. Usar a publicação/ciência efetivamente informada, excluir o dia do marco inicial e iniciar a contagem no próximo dia de segunda a sexta-feira, incluindo feriados. Não alterar a data documental da publicação para ajustá-la ao calendário simplificado. Preservar a quantidade de dias do prazo expresso ou legal de referência.

Apresentar os vencimentos solicitados por esse critério, inclusive os campos de prazo jurídico de referência, com uma indicação breve fora dos resumos: **“Contagem solicitada: segunda a sexta, incluindo feriados; vencimentos sem validação do calendário judicial oficial.”** Não apresentar essas datas como vencimentos jurídicos oficiais confirmados. Data-limite expressamente fixada no ato não pode ser substituída por uma contagem derivada; preservar a data determinada. Prazos em horas ou corridos, especialmente criminais, conservam sua unidade e regime próprios; não transformar dias corridos em dias de segunda a sexta.

Aplicar o mesmo calendário simplificado ao agendamento interno: análise/ciência até 12h no mesmo dia de segunda a sexta; após 12h ou em fim de semana, no próximo dia de segunda a sexta. Prioridades RPV/Suhiane e aviso/instrução social usam o próximo dia de segunda a sexta. D-2 corresponde a retroceder dois dias de segunda a sexta do vencimento de referência, incluindo feriados no percurso. Manter data e horário exatos de audiências, perícias e sustentações, sem aplicar D-2 ao comparecimento.

**Exemplo:** publicação em 29/10/2026 e prazo de 5 dias: contar 30/10, 02/11, 03/11, 04/11 e 05/11. Vencimento de referência: **05/11/2026**; D-2: **03/11/2026**. Não excluir 30/10 ou 02/11 por feriado/suspensão.

Separar data de lançamento no VIOS, vencimento de referência e controle D-2. Consultar o horário atual de America/Sao_Paulo (ou horário informado pelo usuário); não presumir lançamento de manhã. Nas demais seções e referências, interpretar “dia útil” e “dia de expediente do escritório” como segunda a sexta, inclusive feriados, para a contagem simplificada. “Prazo jurídico/vencimento jurídico” nos modelos representa referência calculada pelo critério solicitado, não validação oficial.

| Situação | Data da tarefa no VIOS | Descrição |
| --- | --- | --- |
| RPV/precatório e prioridades da Suhiane, inclusive emenda à inicial | Primeiro dia de expediente do escritório seguinte ao recebimento/lançamento em análise | Cabeçalho de prazo no padrão abaixo; prioridade não substitui o vencimento jurídico nem o D-2 |
| Analisar, ciência e verificar viabilidade de sustentação | Mesmo dia de expediente do escritório até 12h; após 12h ou fora de expediente, próximo dia de expediente do escritório | Análise de sentença/acórdão/decisão: duas datas recursais em D-2; ciência sem prazo não recebe prazo inventado |
| Aviso e instrução de perícia social | Primeiro dia de expediente do escritório após a análise, na mesma data para ambas | Não confundir orientação/aviso com o comparecimento à visita |
| Audiência, perícia com comparecimento e sustentação oral | Data e horário exatos do ato; sessão virtual no início da sessão | Modelo curto de evento; preencher também o horário no campo próprio do VIOS |
| Demais tarefas com prazo, inclusive minutar | D-2 | `PRAZO FATAL D -2: DD/MM/AAAA` |

Não estender automaticamente a prioridade a toda tarefa da Suhiane: aplicar as prioridades previstas no fluxo e as expressamente informadas. As exceções prioritárias prevalecem sobre o corte das 12h. Nunca alongar prazo judicial pela rotina interna. Se o ato/prazo ocorrer antes da data operacional, sinalizar urgência e antecipar; se já vencido, informar atraso sem alterar a data original.

Guardar vencimentos de referência, fundamento, duração e o critério simplificado nos campos de controle fora do resumo. A data de trabalho prioritário não é vencimento jurídico. Nas descrições prioritárias com prazo único, seguir esta ordem:

```text
PRAZO FATAL: [data de controle D-2]
PRIORIDADE RPV
[resumo breve da providência ou do ato]
```

Usar `PRIORIDADE RPV` somente em RPV/precatório. Para outra prioridade da Suhiane, identificar a prioridade pertinente sem chamá-la de RPV. Na minuta de dados de requisitórios, seguir o exemplo específico do usuário: `PRAZO FATAL: [D-2]`, título da minuta e breve despacho, sem linhas de responsável, auxiliar ou marcador final de prioridade. Registrar a prioridade nos campos de controle. Na análise jurídica de sentença/acórdão/decisão ligada a RPV, manter as duas linhas recursais e o marcador de prioridade abaixo, sem terceira linha de prazo fatal.


## Prazos para embargos e recurso

- Para toda análise jurídica de sentença, acórdão ou decisão, apresentar obrigatoriamente as duas datas abaixo, em D-2, nesta ordem, sem acrescentar `PRAZO FATAL`:

```text
PRAZO DE EMBARGOS: DD/MM/AAAA
PRAZO DE RECURSO: DD/MM/AAAA
[SENTENÇA/ACÓRDÃO/DECISÃO e resumo breve]
```

- Calcular as duas datas mesmo quando a triagem indicar possível incabimento de um ou de ambos. Sem prazo expresso, usar o prazo legal de referência do rito/meio correspondente. A decisão sobre cabimento pertence ao advogado. Não substituir uma data por `NÃO CABE` nem omitir a linha por conclusão automática de incabimento. Registrar eventual restrição legal e o caráter preventivo fora da descrição, sem apresentar esse controle como afirmação de que o recurso é admissível.
- Não inventar termo inicial, meio recursal, calendário ou duração quando faltarem elementos. Se não houver base para calcular uma das duas datas, bloquear a tarefa e listar a conferência necessária fora do arquivo de lançamento.
- Usar somente `PRAZO FATAL` em análise operacional de obrigação com prazo certo que não seja avaliação jurídica de sentença/acórdão/decisão e não envolva controle recursal. Exemplo: conferir minuta de requisitório com prazo objetivo. Não usar essa exceção para retirar as duas datas de uma análise jurídica.
- Nunca reunir os três cabeçalhos na mesma descrição: usar embargos + recurso OU prazo fatal. Minutas usam `PRAZO FATAL D -2:`; a minuta prioritária de requisitórios usa a apresentação específica acima, mantendo a data D-2.
- Se houver obrigação objetiva distinta na mesma intimação, preservar seu prazo nos campos externos e, quando o fluxo exigir, em tarefa própria. Não abrir antecipadamente minuta de recurso/embargos que depende da decisão do advogado na análise.
- Conferir regras especiais, inclusive homologação de conciliação no JEC, efeitos do julgamento de embargos e honorários recursais, conforme a referência. Não converter controle preventivo em conclusão jurídica de cabimento.


## Complementares e situações específicas

- Sustentação oral: indicar viabilidade e sustentação, em blocos próprios e datas distintas conforme a tabela. Separar prazo de envio/inscrição da data da sessão.
- Perícia médica previdenciária: indicar `PERÍCIA MÉDICA JUDICIAL (PREVIDENCIÁRIO) 2026` e `MINUTAR PETIÇÃO INTERMEDIÁRIA/RÉPLICA/IMPUGNAÇÃO LAUDO (PREVIDENCIÁRIO) 2026` para quesitos e assistente técnico. Preservar prazo específico ou marcar pendência, sem presumir prazo não confirmado. Laudo já juntado, sem nova perícia, não gera tarefa de comparecimento nem de quesitos automaticamente.
- Perícia social previdenciária: indicar `AVISAR PERÍCIA SOCIAL JUDICIAL (PREVIDENCIÁRIO) 2026`, para Leticya, e `INSTRUÇÃO PERÍCIA SOCIAL JUDICIAL (PREVIDENCIÁRIO) 2026` na mesma data operacional. Confirmar responsável pela instrução, sem presumir que seja o do aviso. Se a visita for expressamente sem agendamento, indicar ambas sem inventar data/hora de comparecimento; se os dados existirem em ID/evento/expediente ainda não lido, bloquear e listar a pendência fora do arquivo. Se solicitar dados/documentos, acrescentar minuta previdenciária para Suhiane, com prazo e data operacional próprios, preservando o prazo jurídico. Não substituir uma tarefa pela outra.
- No aviso social, usar o aviso padrão em negrito e sublinhado e, abaixo, breve trecho principal entre aspas. Consultar o POP para o texto.
- Manifestação sobre laudo previdenciário ou proposta de acordo do INSS: usar a tarefa oficial de petição intermediária/réplica/impugnação laudo. Conferir eventual prazo específico nos autos antes de validar prazo legal subsidiário.
- Pagamento pelo cliente no Trabalhista: indicar primeiro análise da área; não gerar guia nem minuta inicial. A análise gera contato para avisar e consultar o cliente antes da guia. Após autorização e pagamento, seguir a comprovação nos autos.
- Pagamento pelo cliente no Cível: indicar somente análise e minuta cível para comprovar pagamento/depósito/recolhimento. A análise já gera automaticamente o contato com o cliente; não indicar `ENTRAR EM CONTATO COM O CLIENTE 2026` como tarefa adicional. Aplicar a custas, honorários e parcelamento; não substituir por ciência ou guia isolada.
- Petições intermediárias da Execução da Tamira, inclusive opções equivalentes a `MINUTAR PETIÇÃO (EXECUÇÃO)`: informar Tamira como auxiliar e Breno como responsável nos campos próprios, fora da descrição. Não estender automaticamente a recursos, análise, cálculos ou outras tarefas especializadas.
- Audiência: identificar tipo, data, horário, formato, local/link, ID e senha. Sempre que a intimação fornecer link encurtado, usar esse link no campo LINK/LOCAL e na descrição da audiência, conforme o POP. Não tratar audiência inicial automaticamente como UNA. Em audiência cível com cliente réu, conferir contestação; se ausente, indicar também `MINUTAR INICIAL/CONTESTAÇÃO/EMBARGOS À EXECUÇÃO (CÍVEL) 2026` para defesa.
- Cálculos trabalhistas: usar `MINUTAR PETIÇÃO INTERMEDIÁRIA DIVERSA (TRABALHISTA) 2026` quando não houver opção específica.
- Recurso/agravo trabalhista genérico: verificar quem recorreu e se há abertura de resposta. Parte contrária com resposta exigida: minuta; recurso só do cliente e sem providência: ciência. Se não identificável, usar `NÃO ABRIR TAREFA AINDA - CONFERIR NO PJE QUEM INTERPÔS O AGRAVO/RECURSO PARA DEFINIR SE É MINUTAR OU CIÊNCIA`. Não criar tarefa apenas para o advogado buscar essa informação.

## Saída para análise de arquivo VIOS

Apresentar uma CI por bloco, na ordem e numeração originais, mesmo quando duplicada. Nunca fundir cabeçalhos. Separar campos e tarefas com linhas em branco. Repetir dados próprios de cada processo, sem misturar clientes, IDs, valores ou datas.

```text
## [n]. CI [número] — Processo [número]

Cliente: [nome e posição processual]
Auxiliar/Departamento: [cadastro e eventual pendência]
Do que se trata: [explicação objetiva]

Tarefa 1 no VIOS: [nome exato]
Finalidade: [providência]
Responsável/Auxiliar: [quando aplicável]
Data da tarefa: [data correta e motivo, ou pendência]
Prazo fatal: [vencimento jurídico da obrigação/meio identificado, ou pendência]
[Cabeçalho de prazo conforme a tabela; separar data prioritária do controle D-2]

Cabe recurso? [meio e análise de cabimento]
[PRAZO DE EMBARGOS: data D-2, nas análises jurídicas]
[PRAZO DE RECURSO: data D-2, nas análises jurídicas]

Resumo para tarefa 1:
[Linhas operacionais apropriadas e texto curto pronto para copiar]

Tarefa complementar: [cada uma em bloco próprio, com finalidade, data e resumo]
Observação/Pendências: [dados faltantes, destinatário, divergência e validação]
Status: [PRONTA PARA LANÇAMENTO / NÃO LANÇAR — providência faltante / DUPLICADA DA CI ...]
```

No resumo da tarefa usar o controle D-2 apropriado, sem confundi-lo com o dia de agendamento prioritário ou de análise. Se houver embargos e outro recurso, identificar os dois vencimentos jurídicos separadamente fora do resumo; não usar um único “prazo fatal” sem dizer a que corresponde. Para audiência/perícia/sustentação usar o modelo do ato, sem D-2 sobre a data de comparecimento.

## Saída para revisão de análises e duplicidades

Quando o usuário pedir somente revisão, erros ou duplicidades, não repetir obrigatoriamente 23 ou mais análises completas. Informar quantas CIs/processos foram conferidos, listar duplicidades confirmadas e prováveis com suas evidências, depois erros por CI com correção. Separar erro confirmado, inconsistência interna, pendência documental e hipótese preventiva. Usar tabela quando facilitar a comparação.

Não afirmar que tudo está correto se só houver resumos. Indicar o que pôde ser validado e o que depende de intimação/acordo/laudo/decisão original. Não afirmar acesso ao VIOS/PJe nem lançamento sem ação efetiva autorizada.

## Conferência final

Conferir uma linha interna por CI: cliente, destinatário, ato/ID, natureza, fase, departamento, auxiliar, tarefa principal/complementares, responsável, prazo jurídico, termo inicial, calendário/fonte, data operacional, prioridade, duplicidade e status.

- Revisar todas as CIs e suas tarefas; não encerrar por dúvida de uma CI deixando as demais sem análise.
- Verificar a instrução em toda perícia social, os quesitos na perícia médica e as duas tarefas de sustentação.
- Confirmar o corte das 12h para análise/ciência, o próximo dia de expediente do escritório para prioridades e a separação entre calendário interno, D-2 da descrição e vencimento jurídico.
- Conferir Breno nas petições intermediárias da Execução da Tamira.
- Não lançar nem incluir no arquivo importável tarefa indefinida, duplicada, com área/cliente/responsável incertos ou com dado indispensável ausente. Registrar exatamente o que a Controladoria deve conferir.
- Perguntar somente após ler os documentos e apenas sobre dados que não possam ser obtidos das fontes disponíveis. Entregar as pendências em bloco único; não perguntar qual modelo usar quando a regra já o define.

## Arquivo de lançamento e pendências fora do arquivo

Respeitar o modelo de arquivo fornecido pelo usuário; entregar somente um arquivo quando solicitado. Incluir nesse arquivo apenas tarefas completas e prontas. Não criar tarefa para mandar o advogado descobrir informação necessária à triagem. Quando faltar leitura de ID, evento ou expediente, data/horário/local, responsável ou outro dado indispensável, excluir a tarefa afetada do arquivo e listar no chat, fora dele: CI, processo, tarefa bloqueada, dado faltante e conferência exata a realizar no sistema. Informar totais de CIs conferidas, tarefas prontas, duplicidades e pendências, sem confundir quantidade de tarefas com quantidade de CIs. Preservar todas as CIs na conferência interna e explicar qualquer exclusão.

Manter a descrição breve, pronta para copiar, sem responsáveis/auxiliares, fundamentos extensos, transcrição longa, instruções de cadastro ou OBS genérica. Consultar os modelos curtos de audiência e sustentação no POP. Confirmar responsável e auxiliar nos campos próprios; nunca atribuir tarefa a Sarah Pontes/Controladoria, nem usar seu nome como alternativa à falta de responsável.
